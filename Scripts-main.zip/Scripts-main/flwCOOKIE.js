

//独立COOKIE文件     ck在``里面填写，多账号换行
let flwurlVal= ``
let flwheaderVal= ``
let flwspbodyVal= ``
let flwqwbodyVal= ``
let flwydbodyVal= ``


let flwcookie = {
  flwurlVal: flwurlVal,  
  flwheaderVal: flwheaderVal,  
  flwspbodyVal: flwspbodyVal, 
  flwqwbodyVal: flwqwbodyVal, 
  flwydbodyVal: flwydbodyVal, 

}

module.exports =  flwcookie
  

