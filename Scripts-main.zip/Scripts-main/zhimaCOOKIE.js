

//独立COOKIE文件     ck在``里面填写，多账号换行

let zhimabodyVal= ``


let zhimacookie = {

  zhimabodyVal: zhimabodyVal,  
  
}

module.exports =  zhimacookie
  
